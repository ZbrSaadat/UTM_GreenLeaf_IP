package my.utm.greenleaf.model;

import java.time.LocalDateTime;

public class Activity {

    private String title;
    private String category;
    private String summary;
    private String submittedBy;
    private LocalDateTime submittedAt;

    public Activity() {
    }

    public Activity(String title, String category, String summary,
                    String submittedBy, LocalDateTime submittedAt) {
        this.title = title;
        this.category = category;
        this.summary = summary;
        this.submittedBy = submittedBy;
        this.submittedAt = submittedAt;
    }

    // getters & setters

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getSubmittedBy() {
        return submittedBy;
    }

    public void setSubmittedBy(String submittedBy) {
        this.submittedBy = submittedBy;
    }

    public LocalDateTime getSubmittedAt() {
        return submittedAt;
    }

    public void setSubmittedAt(LocalDateTime submittedAt) {
        this.submittedAt = submittedAt;
    }
}
