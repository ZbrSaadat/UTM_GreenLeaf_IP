package my.utm.greenleaf.entity;

public enum Role {
    USER, ADMIN
}
