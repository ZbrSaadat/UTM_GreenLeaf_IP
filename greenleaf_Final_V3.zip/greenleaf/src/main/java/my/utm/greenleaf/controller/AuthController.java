package my.utm.greenleaf.controller;

import my.utm.greenleaf.entity.Role;
import my.utm.greenleaf.entity.User;
import my.utm.greenleaf.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final UserRepository userRepo;
    private final PasswordEncoder encoder;

    public AuthController(UserRepository userRepo, PasswordEncoder encoder) {
        this.userRepo = userRepo;
        this.encoder = encoder;
    }

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("activePage", "login");
        return "login";
    }

    @GetMapping("/register")
    public String register(Model model) {
        model.addAttribute("activePage", "register");
        model.addAttribute("error", null);
        return "register";
    }

    @PostMapping("/register")
    public String registerSubmit(@RequestParam String fullName,
                                 @RequestParam String email,
                                 @RequestParam String password,
                                 Model model) {

        String cleanedEmail = email.trim().toLowerCase();

        if (userRepo.existsByEmail(cleanedEmail)) {
            model.addAttribute("activePage", "register");
            model.addAttribute("error", "Email already registered.");
            return "register";
        }

        User u = new User();
        u.setFullName(fullName);
        u.setEmail(cleanedEmail);
        u.setPasswordHash(encoder.encode(password));
        u.setRole(Role.USER);     // ✅ Option A
        u.setActive(true);

        userRepo.save(u);
        return "redirect:/login?registered";
    }
}
