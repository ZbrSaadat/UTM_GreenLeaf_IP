package my.utm.greenleaf.entity;

public enum SubmissionStatus {
    PENDING, APPROVED, REVISION, REJECTED
}
