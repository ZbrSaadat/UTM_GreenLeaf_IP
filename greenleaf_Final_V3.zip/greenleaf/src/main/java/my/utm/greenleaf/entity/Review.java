package my.utm.greenleaf.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="reviews")
public class Review {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(optional=false)
    @JoinColumn(name="submission_id", unique=true)
    private Submission submission;

    @ManyToOne(optional=false)
    @JoinColumn(name="admin_id")
    private User admin;

    private Integer score;

    @Column(columnDefinition = "TEXT")
    private String feedback;

    @Column(nullable=false)
    private LocalDateTime reviewedAt = LocalDateTime.now();

    // getters/setters
    public Long getId(){ return id; }
    public Submission getSubmission(){ return submission; }
    public void setSubmission(Submission submission){ this.submission = submission; }
    public User getAdmin(){ return admin; }
    public void setAdmin(User admin){ this.admin = admin; }
    public Integer getScore(){ return score; }
    public void setScore(Integer score){ this.score = score; }
    public String getFeedback(){ return feedback; }
    public void setFeedback(String feedback){ this.feedback = feedback; }
    public LocalDateTime getReviewedAt(){ return reviewedAt; }
}
