package my.utm.greenleaf.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="submissions")
public class Submission {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional=false)
    @JoinColumn(name="user_id")
    private User user;

    @Column(nullable=false)
    private String title;

    @Column(nullable=false)
    private String category;

    @Column(columnDefinition = "TEXT")
    private String description;

    // stored filename in C:\greenleaf_uploads
    private String evidenceFileName;

    @Enumerated(EnumType.STRING)
    @Column(nullable=false)
    private SubmissionStatus status = SubmissionStatus.PENDING;

    @Column(nullable=false)
    private LocalDateTime createdAt = LocalDateTime.now();

    // getters/setters
    public Long getId(){ return id; }
    public User getUser(){ return user; }
    public void setUser(User user){ this.user = user; }
    public String getTitle(){ return title; }
    public void setTitle(String title){ this.title = title; }
    public String getCategory(){ return category; }
    public void setCategory(String category){ this.category = category; }
    public String getDescription(){ return description; }
    public void setDescription(String description){ this.description = description; }
    public String getEvidenceFileName(){ return evidenceFileName; }
    public void setEvidenceFileName(String evidenceFileName){ this.evidenceFileName = evidenceFileName; }
    public SubmissionStatus getStatus(){ return status; }
    public void setStatus(SubmissionStatus status){ this.status = status; }
    public LocalDateTime getCreatedAt(){ return createdAt; }
}
