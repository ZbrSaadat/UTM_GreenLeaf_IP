package my.utm.greenleaf.controller;

import my.utm.greenleaf.entity.Submission;
import my.utm.greenleaf.entity.User;
import my.utm.greenleaf.repository.SubmissionRepository;
import my.utm.greenleaf.repository.UserRepository;
import my.utm.greenleaf.service.FileStorageService;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Path;

@Controller
public class GreenleafController {

    private final UserRepository userRepo;
    private final SubmissionRepository submissionRepo;
    private final FileStorageService storage;

    public GreenleafController(UserRepository userRepo,
                              SubmissionRepository submissionRepo,
                              FileStorageService storage) {
        this.userRepo = userRepo;
        this.submissionRepo = submissionRepo;
        this.storage = storage;
    }

    @GetMapping("/greenleaf")
    public String platform(Authentication auth, Model model) {
        model.addAttribute("activePage", "platform");
        User user = userRepo.findByEmail(auth.getName()).orElseThrow();
        model.addAttribute("submissions",
                submissionRepo.findByUserIdOrderByCreatedAtDesc(user.getId()));
        return "greenleaf";
    }

    @PostMapping("/greenleaf/submit")
    public String submit(Authentication auth,
                         @RequestParam String title,
                         @RequestParam String category,
                         @RequestParam(required = false) String description,
                         @RequestParam(required = false) MultipartFile evidenceFile) throws Exception {

        User user = userRepo.findByEmail(auth.getName()).orElseThrow();
        String storedName = storage.save(evidenceFile);

        Submission s = new Submission();
        s.setUser(user);
        s.setTitle(title);
        s.setCategory(category);
        s.setDescription(description);
        s.setEvidenceFileName(storedName);

        submissionRepo.save(s);
        return "redirect:/greenleaf?submitted";
    }

    @GetMapping("/evidence/{filename}")
    public ResponseEntity<Resource> downloadEvidence(@PathVariable String filename) throws Exception {
        Path p = storage.resolve(filename);
        Resource r = new UrlResource(p.toUri());
        if (!r.exists()) return ResponseEntity.notFound().build();

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + r.getFilename() + "\"")
                .body(r);
    }
}
