package my.utm.greenleaf.repository;

import my.utm.greenleaf.entity.Submission;
import my.utm.greenleaf.entity.SubmissionStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SubmissionRepository extends JpaRepository<Submission, Long> {
    List<Submission> findByUserIdOrderByCreatedAtDesc(Long userId);
    List<Submission> findByStatusOrderByCreatedAtDesc(SubmissionStatus status);
    long countByStatus(SubmissionStatus status);
}
