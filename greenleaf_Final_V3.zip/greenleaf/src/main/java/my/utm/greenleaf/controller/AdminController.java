package my.utm.greenleaf.controller;

import my.utm.greenleaf.entity.*;
import my.utm.greenleaf.repository.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final UserRepository userRepo;
    private final SubmissionRepository submissionRepo;
    private final ReviewRepository reviewRepo;

    public AdminController(UserRepository userRepo,
                           SubmissionRepository submissionRepo,
                           ReviewRepository reviewRepo) {
        this.userRepo = userRepo;
        this.submissionRepo = submissionRepo;
        this.reviewRepo = reviewRepo;
    }

    @GetMapping("/review")
    public String review(Model model) {
        model.addAttribute("activePage", "adminReview");
        model.addAttribute("pending",
                submissionRepo.findByStatusOrderByCreatedAtDesc(SubmissionStatus.PENDING));
        model.addAttribute("pendingCount", submissionRepo.countByStatus(SubmissionStatus.PENDING));
        model.addAttribute("approvedCount", submissionRepo.countByStatus(SubmissionStatus.APPROVED));
        return "admin-review";
    }

    @PostMapping("/review/{id}")
    public String submitReview(@PathVariable Long id,
                               @RequestParam Integer score,
                               @RequestParam String feedback,
                               @RequestParam SubmissionStatus status,
                               Authentication auth) {

        User admin = userRepo.findByEmail(auth.getName()).orElseThrow();
        Submission s = submissionRepo.findById(id).orElseThrow();

        s.setStatus(status);
        submissionRepo.save(s);

        Review r = reviewRepo.findBySubmissionId(id).orElseGet(Review::new);
        r.setSubmission(s);
        r.setAdmin(admin);
        r.setScore(score);
        r.setFeedback(feedback);
        reviewRepo.save(r);

        return "redirect:/admin/review?done";
    }

    @GetMapping("/reports")
    public String reports(Model model) {
        model.addAttribute("activePage", "adminReports");
        model.addAttribute("users", userRepo.findAll());
        model.addAttribute("totalUsers", userRepo.count());
        model.addAttribute("totalSubmissions", submissionRepo.count());
        model.addAttribute("pendingCount", submissionRepo.countByStatus(SubmissionStatus.PENDING));
        model.addAttribute("approvedCount", submissionRepo.countByStatus(SubmissionStatus.APPROVED));
        return "admin-reports";
    }

    @PostMapping("/users/{id}/toggle")
    public String toggle(@PathVariable Long id) {
        User u = userRepo.findById(id).orElseThrow();
        u.setActive(!u.isActive());
        userRepo.save(u);
        return "redirect:/admin/reports?userUpdated";
    }

    @PostMapping("/users/{id}/promote")
    public String promote(@PathVariable Long id) {
        User u = userRepo.findById(id).orElseThrow();
        u.setRole(Role.ADMIN);
        userRepo.save(u);
        return "redirect:/admin/reports?promoted";
    }

    @GetMapping("/reports/export.csv")
    public ResponseEntity<byte[]> exportCsv() {
        List<Submission> all = submissionRepo.findAll();
        StringBuilder sb = new StringBuilder();
        sb.append("id,userEmail,title,category,status,createdAt\n");
        for (Submission s : all) {
            sb.append(s.getId()).append(",")
              .append(s.getUser().getEmail()).append(",")
              .append(csv(s.getTitle())).append(",")
              .append(csv(s.getCategory())).append(",")
              .append(s.getStatus()).append(",")
              .append(s.getCreatedAt()).append("\n");
        }

        byte[] bytes = sb.toString().getBytes(StandardCharsets.UTF_8);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_TYPE, "text/csv; charset=utf-8")
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"greenleaf_report.csv\"")
                .body(bytes);
    }

    private String csv(String x) {
        if (x == null) return "";
        String v = x.replace("\"", "\"\"");
        if (v.contains(",") || v.contains("\n")) return "\"" + v + "\"";
        return v;
    }
}
